package edu.ufl.cise.cs1.controllers;

import game.controllers.AttackerController;
import game.models.Attacker;
import game.models.Defender;
import game.models.Game;
import game.models.Node;

import java.util.ArrayList;
import java.util.List;

public final class StudentAttackerController implements AttackerController {

    public void init(Game game) {
    }

    public void shutdown(Game game) {
    }

    public int update(Game game, long timeDue) {
        int action = -1;
        Attacker attacker = game.getAttacker();
        Node powerPillLocation = attacker.getTargetNode(game.getPowerPillList(), true);
        Node pillLocation = attacker.getTargetNode(game.getPillList(), true);



        if (game.getPillList().size() != 0) {                                               //Get Pills State
            action = attacker.getNextDir(pillLocation, true);
        }
        if (!(vulnerableDefendersNode(game.getDefenders()).size() == 0)) {                                                   //Attack Vulnerable Defenders State
            action = attacker.getNextDir(attacker.getTargetNode(vulnerableDefendersNode(game.getDefenders()), true), true);
        }
        if (isOkToChasePowerPill(game, attacker)) {                                        //Get Power Pills State
            action = attacker.getNextDir(powerPillLocation, true);
        }
        if (inDanger(game, attacker)) {                                                    //Flee State
            action = attacker.getNextDir(attacker.getTargetNode(noNullDirectionsNode(game), true), false);
        }
        if (game.getPowerPillList().contains(attacker.getLocation().getNeighbor(attacker.getDirection())) && dangerousDefendersNode(game.getDefenders()).size() != 0) {
            if (attacker.getLocation().getPathDistance(attacker.getTargetNode(dangerousDefendersNode(game.getDefenders()),true)) < 8){
                action = attacker.getNextDir(powerPillLocation, true);
            }
            else {
                action = attacker.getReverse();
            }
        }

        return action;
    }

    //Pill Chasing Methods
    private boolean isOkToChasePowerPill(Game game, Attacker attacker) {
        if (game.getPowerPillList().size() == 0) {
            return false;
        }
        boolean minimumDistance = attacker.getLocation().getPathDistance(attacker.getTargetNode(game.getPowerPillList(), true)) < 50;
        return !allVulnerable(game) && minimumDistance && defendersAllOut(game) && highDensityDefenders(game, attacker);
    }               //Returns true if PowerPill should be chased based on specific attributes

    private boolean allVulnerable(Game game) {
        int counter = 0;
        for (int i = 0; i < game.getDefenders().size(); i++) {
            if (game.getDefender(i).isVulnerable()) {
                counter++;
            }
        }
        return counter == 4;
    }                                         //Returns true if all defenders are vulnerable

    private boolean defendersAllOut(Game game) {
        int counter = 0;
        for (int i = 0; i < game.getDefenders().size(); i++) {
            if (game.getDefender(i).getLairTime() == 0) {
                counter++;
            }
        }

        return counter == 4;
    }                                       //Returns true if no defenders reside in the lair

    private boolean highDensityDefenders(Game game, Attacker attacker) {

        int counter = 0;
        for (int i = 0; i < game.getDefenders().size(); i++) {
            if (attacker.getLocation().getPathDistance(attacker.getTargetNode(defendersToNode(game), true)) < 150) {
                counter++;
            }
        }

        return counter >= 3;
    }               //Returns true if there is a high density of Defenders near the Attacker
    //**************************************************************************************************

    //Flee Methods
    private boolean inDanger(Game game, Attacker attacker) {
        int counter = 0;

        if (!defendersAllOut(game)) {
            return false;
        }

        List<Node> targetNodeList = dangerousDefendersNode(game.getDefenders());
        if (dangerousDefendersNode(game.getDefenders()).size() == 0) {
            return false;
        }

        for (int i = 0; i < game.getDefenders().size(); i++) {
            if (attacker.getLocation().getPathDistance(attacker.getTargetNode(targetNodeList, true)) < 8) {
                counter++;
            }
        }

        return counter != 0;

    }                           //Returns True if Attacker is in Danger of being killed

    private List<Node> dangerousDefendersNode(List<Defender> defenderList) {

        List<Node> defenderNode = new ArrayList<>(4);
        for (int i = 0; i < defenderList.size(); i++) {
            if (!defenderList.get(i).isVulnerable()) {
                defenderNode.add(defenderList.get(i).getLocation());
            }
        }
        return defenderNode;

    }           //Returns a Node List of non-vulnerable Defenders

    private int indexOfClosestDefender(List<Node> defenderList, Game game) {
        int index = 0;                                                                        //place defender distances into array
        int[] array = new int[defenderList.size()];
        int[] tempArray = new int[array.length];
        for (int i = 0; i < defenderList.size(); i++) {
            array[i] = defenderList.get(i).getPathDistance(game.getAttacker().getLocation());
        }

        int counter = 0;
        while (counter < defenderList.size()) {                                                 //sort array from lowest to highest
            for (int i = 0; i < defenderList.size() - 1; i++) {
                if (array[i] > array[i + 1]) {
                    tempArray[0] = array[i + 1];
                    array[i + 1] = array[i];
                    array[i] = tempArray[0];
                }
            }
            counter++;
        }

        for (int i = 0; i < defenderList.size(); i++) {                                          //match lowest value with correct defender
            if (array[0] == defenderList.get(i).getPathDistance(game.getAttacker().getLocation())) {
                index = i;
            }
        }
        return index;
    }           //Returns the index of non-vulnerable Defenders in the Defender Node List

    private List<Node> nonEmptyValues(List<Node> node) {
        List<Node> nonEmptyValues = new ArrayList<>();

        for (int i = 0; i < node.size(); i++) {
            if (node.get(i) != null) {
                nonEmptyValues.add(node.get(i));
            }
        }

        return nonEmptyValues;
    }                               //Removes null entries of Node List Input

    private List<Node> noNullDirectionsNode(Game game) {
        int index = indexOfClosestDefender(defendersToNode(game), game);
        List<Node> possibleLocationsNode = game.getDefender(index).getPossibleLocations();
        return nonEmptyValues(possibleLocationsNode);
    }                               //Returns Node List without null entries (for Get-Defender-Location)

    //**************************************************************************************************

    //Attack Methods

    private List<Node> vulnerableDefendersNode(List<Defender> defenderList) {

        List<Node> defenderNode = new ArrayList<>(4);
        for (int i = 0; i < defenderList.size(); i++) {
            if (defenderList.get(i).isVulnerable()) {
                defenderNode.add(defenderList.get(i).getLocation());
            }
        }
        return defenderNode;

    }           //Returns a Node List of Vulnerable Defenders

    //**************************************************************************************************

    //Helper Methods
    private List<Node> defendersToNode(Game game) {
        List<Node> defenderList = new ArrayList<>(4);
        for (int i = 0; i < game.getDefenders().size(); i++) {
            defenderList.add(i, game.getDefender(i).getLocation());
        }
        return defenderList;

    }                                     //Method used to convert from Defender List to Node List

}